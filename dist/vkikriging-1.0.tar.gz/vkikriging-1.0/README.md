Kriging code
============







R. Dwight 2018
